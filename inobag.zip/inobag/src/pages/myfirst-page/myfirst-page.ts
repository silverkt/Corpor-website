import { Component, ViewChild } from '@angular/core';

//import { NavController, NavParams } from 'ionic-angular';
import { Navbar, NavParams, NavController } from "ionic-angular";
import { ActionSheetController } from 'ionic-angular';
import { AlertController } from 'ionic-angular';


import { MysecondPage } from '../mysecond-page/mysecond-page';

@Component({
  selector: 'myfirst-page',
  templateUrl: 'myfirst-page.html'
})
export class MyfirstPage {
  testRadioOpen: boolean;
  testRadioResult;

  testCheckboxOpen: boolean;
  testCheckboxResult;

  public date = {
    month: '1990-02-19',
    timeStarts: '07:43',
    timeEnds: '1990-02-20'
  }

  public press: number = 0;
  public pan: number = 0;
  public swipe: number = 0;
  public tap: number = 0;

  @ViewChild(Navbar) navbar: Navbar  
  mytitle: string = "这是标题";
  content: string;
  constructor(
    public params: NavParams, 
    public actionSheetCtrl: ActionSheetController,
    public alertCtrl: AlertController,
    public NavCtrl: NavController
    ) { }
  ionViewWillEnter() {
    this.content = this.params.get('data');
    this.navbar.setBackButtonText('返回');
  }

  presentActionSheet() {
    let actionSheet = this.actionSheetCtrl.create({
      title: '修改你的相册',
      buttons: [
        {
          text: '新建',
          role: 'destructive',
          handler: () => {
            console.log('Destructive clicked');
          }
        },{
          text: '测试',
          
          handler: () => {
            console.log('Destructive clicked');
          }
        },{
          text: '成功',
          handler: () => {
            console.log('Archive clicked');
          }
        },{
          text: '取消',
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        }
      ]
    });
    actionSheet.present();
  }


  presentAlert() {
    let alert = this.alertCtrl.create({
      title: "提示！",
      subTitle: '这仅仅是一个测试，this is a shit',
      buttons: [ {
          text: '新建',
          role: 'destructive',
          handler: () => {
            console.log('提示 clicked');
          }
        }]
    });
    alert.present();
  }



  presentPrompt() {
    let prompt = this.alertCtrl.create({
      title: '输入',
      message: "输入一点shit",
      inputs: [
        {
          name: 'title',
          placeholder: '输入内容'
        },
      ],
      buttons: [
        {
          text: '取消',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: '保存',
          handler: data => {
            console.log(data.title+'Saved clicked');
             
          }
        }
      ]
    });
    prompt.present();
  }


  presentRadio() {
    let alert = this.alertCtrl.create();
    alert.setTitle('Lightsaber color');

    alert.addInput({
          type: 'radio',
          label: 'Blue',
          value: 'blue',
          checked: true
        });

        alert.addInput({
          type: 'radio',
          label: 'Green',
          value: 'green'
        });

        alert.addInput({
          type: 'radio',
          label: 'Red',
          value: 'red'
        });

        alert.addInput({
          type: 'radio',
          label: 'Yellow',
          value: 'yellow'
        });

        alert.addInput({
          type: 'radio',
          label: 'Purple',
          value: 'purple'
        });

        alert.addInput({
          type: 'radio',
          label: 'White',
          value: 'white'
        });

        alert.addInput({
          type: 'radio',
          label: 'Black',
          value: 'black'
    });

    alert.addButton('Cancel');
    alert.addButton({
      text: 'OK',
      handler: data => {
        this.testRadioOpen = false;
        this.testRadioResult = data;
      }
    });
    alert.present();
  }


  presentCheckbox() {
    let alert = this.alertCtrl.create();
    alert.setTitle('Which planets have you visited?');

    alert.addInput({
      type: 'checkbox',
      label: 'Alderaan',
      value: 'value1',
      checked: true
    });

    alert.addInput({
      type: 'checkbox',
      label: 'Bespin',
      value: 'value2'
    });

    alert.addButton('Cancel');
    alert.addButton({
      text: 'Okay',
      handler: data => {
        console.log('Checkbox data:', data);
        this.testCheckboxOpen = false;
        this.testCheckboxResult = data;
      }
    });
    alert.present();
  }


  pressEvent(e) {
    this.press++
  }
  panEvent(e) {
    this.pan++
  }
  swipeEvent(e) {
    this.swipe++
  }
  tapEvent(e) {
    this.tap++
 }

 gotoNewPage(){
   this.NavCtrl.push(MysecondPage,{
     data: 'shit two'
   })
 }


}
