import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { MyfirstPage} from '../myfirst-page/myfirst-page';

@Component({
  selector: 'page-hello-ionic',
  templateUrl: 'hello-ionic.html'
})
export class HelloIonicPage {
  constructor(public navi: NavController) {

  }

  mypage() {
    this.navi.push(MyfirstPage, {
      data: 'this is shit'
    });
  }
}
