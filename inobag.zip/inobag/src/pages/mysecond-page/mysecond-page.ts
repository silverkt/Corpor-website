import { Component, ViewChild } from '@angular/core';


import { Navbar, NavParams, NavController } from "ionic-angular";

@Component({
  selector: 'mysecond-page',
  templateUrl: 'mysecond-page.html'
})
export class MysecondPage {
  
  @ViewChild(Navbar) navbar: Navbar  
  mytitle: string = "这是标题2";
  content: string;
  constructor(
    public params: NavParams, 

    public NavCtrl: NavController
    ) { }
  ionViewWillEnter() {
    this.content = this.params.get('data');
    this.navbar.setBackButtonText('返回');
  }

   


}
