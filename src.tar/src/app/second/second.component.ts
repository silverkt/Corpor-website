import { Component, OnInit } from '@angular/core';
import { flyIn } from "../animations/fly-in";

@Component({
  selector: 'app-second',
  templateUrl: './second.component.html',
  styleUrls: ['./second.component.css'],
  animations: [
    flyIn
  ]
})
export class SecondComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
