import { MainComponent } from "./main/main.component";

export const routes: any = [
    {
        path: '',
        component: MainComponent
    },
    {
        path: 'shit',
        component: MainComponent
    },
];