import { Injectable } from "@angular/core";
import { Http, Response } from "@angular/http";

@Injectable()
export class DataService {
    constructor(private http: Http){}
    getData(): Promise<any> {
        return this.http.get('http://localhost:4200/data.json').toPromise();
    }
    
}