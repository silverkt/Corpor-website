import { Component } from "@angular/core";

@Component({
    selector: 'chrouter-component',
    templateUrl: 'chrouter.component.html',
    styleUrls: ['chrouter.component.css']
})
export class ChrouterComponent {
    
}